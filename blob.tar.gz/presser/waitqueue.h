#ifndef __H_WAITQUEUE_H__
#define __H_WAITQUEUE_H__

#include "queue.h"
#include "task.h"

/* workaround */
struct scale_arg {
	int				type;
	uint32_t		x;
	uint32_t		y;
	uint32_t		cols;
	uint32_t		rows;
	uint32_t		cl;
	size_t			size;
	uint8_t			data[0];
};

#define WAIT_BLOCK_SIZE(size) (size + sizeof(wb_t) 		\
		+ sizeof(uint32_t) + sizeof(struct scale_arg))

typedef struct task_block wb_t;

typedef struct wait_queue {
	uint32_t					size;
	STAILQ_HEAD(, task_block)	queue;
} wq_t;

static inline wb_t * new_wait_block(size_t size)
{
	return malloc(WAIT_BLOCK_SIZE(size));
}

static inline size_t sizeof_wait_block(wb_t *wb)
{
	return (WAIT_BLOCK_SIZE(wb->size));
}

static inline uint32_t wait_queue_size(wq_t *wq)
{
	return (wq->size);
}

static inline void free_wait_block(wb_t *wb)
{
	free(wb);
}

static inline void wait_enqueue(wq_t *wq, wb_t *wb)
{
	STAILQ_INSERT_TAIL(&wq->queue, wb, tbqe);
	wq->size += 1;
}

static inline wb_t * wait_dequeue(wq_t *wq)
{
	wb_t *wb = NULL;

	if (!STAILQ_EMPTY(&wq->queue)) {
		wb = STAILQ_FIRST(&wq->queue);
		STAILQ_REMOVE_HEAD(&wq->queue, tbqe);
		wq->size -= 1;
	}

	return wb;
}

static inline int wait_empty(wq_t *wq) {
	return (STAILQ_EMPTY(&wq->queue));
}

static inline void init_wait_queue(wq_t *wq)
{
	wq->size = 0;
	STAILQ_INIT(&wq->queue);
}

#endif

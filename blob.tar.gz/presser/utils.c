#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <grp.h>
#include <pwd.h>
#include <sys/prctl.h>
#include <string.h>
#include <sys/utsname.h>
#include <sys/resource.h>

int get_cpu_cores()
{
	return (int)sysconf(_SC_NPROCESSORS_CONF);
}

size_t get_pagesize()
{
	return (size_t)sysconf(_SC_PAGESIZE);
}

int set_proctitle(char **argv, char *title)
{
	int i;
	size_t size = 0;

	//TODO: fill environ

	for (i=0; argv[i]; i++) {
		size += strlen(argv[i]) + 1;
	}

	i = snprintf(argv[0], size, "%s", title);
	if (size > i) {
		memset(argv[0] + i, 0, size-i);
	}
	return prctl(PR_SET_NAME, (unsigned long)title, 0, 0, 0);
}

int set_rlimits(int res, int new)
{
	int ret;
	struct rlimit rl; 

	ret = getrlimit(res, &rl);
	if (ret == -1) return -1; 
	if (new <= rl.rlim_cur) return 0;

	rl.rlim_cur = (rlim_t)new;
	rl.rlim_max = (rlim_t)new;
	ret = setrlimit(res, &rl);
	return ret;
}

uid_t get_user_id(char *user)
{
	struct passwd *pwd;

	pwd = getpwnam(user);
	if (pwd == NULL) return -1; 

	return pwd->pw_uid;
}

gid_t get_group_id(char *group)
{
	struct group *grp;

	grp = getgrnam(group);
	if (grp == NULL) return -1; 

	return grp->gr_gid;
}

int set_user(char *group, char *user)
{
	int ret;
	struct passwd *pwd;
	struct group *grp;

	if (getuid() != 0) return 0;

	if (group && *group) {
		grp = getgrnam(group);
		if (grp == NULL) return -1; 
		ret = setgid(grp->gr_gid);
		if (ret == -1) return -1; 
		if (user) initgroups(user, grp->gr_gid);
	}   
	if (user && *user) {
		pwd = getpwnam(user);
		if (pwd == NULL) return -1; 
		ret = setuid(pwd->pw_uid);
		if (ret == -1) return -1; 
	}   

	return 0;
}

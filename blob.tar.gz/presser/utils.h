#ifndef		__H_UTILS_H__
#define		__H_UTILS_H__

int get_cpu_cores();
size_t get_pagesize();
int set_proctitle(char **argv, char *title);
uid_t get_user_id(char *user);
gid_t get_group_id(char *group);
int set_user(char *group, char *user);
int set_rlimits(int res, int new);

static inline uint32_t calc_elapse
(struct timeval *start, struct timeval *stop)
{
	return ((stop->tv_sec - start->tv_sec) * 1000
			+ (stop->tv_usec - start->tv_usec)/1000);
}

static inline uint32_t update_temp_time(struct timeval *t)
{
	uint32_t ret;
	struct timeval now;
	gettimeofday(&now, NULL);

	ret = calc_elapse(t, &now);

	t->tv_sec = now.tv_sec;
	t->tv_usec = now.tv_usec;

	return ret;
}
#endif

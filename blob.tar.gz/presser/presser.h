#ifndef		__H_PRESSER_H__
#define		__H_PRESSER_H__
#include "task.h"
#include "worker.h"
#include "waitqueue.h"

struct server_config {
	int								daemon;			// daemonize
	uint32_t						qsize;			// max task queue size	
	uint32_t						workers;		// worker process num
	uint32_t						connections;	// max connection
	uint32_t						requests;		// max reqs a worker serves
	uint32_t						cores;			// cpu cores
	uint32_t						timeout;
	size_t							pagesize;		//
	int								port;			// listen port
	char *							addr;			// listen address
	char *							log_path;		// log path
	char *							user;
	char *							group;
};

struct server {
	struct event_base			*base;
	struct evdns_base			*dns;
	struct evhttp				*http;
	tp_t						task_pool;
	tq_t						*worker_queue;
	tq_t						*output_queue;
	wm_t						*module;
	wi_t						*worker_list;
	wq_t						wait_queue;

	uint32_t					connections;
	uint64_t					requests;
	uint64_t					failed_downloads;
	uint64_t					succ_downloads;
	uint64_t					failed_compress;
	uint64_t					succ_compress;
};

typedef struct request {
	struct server				*server;
	struct evhttp_request		*http_req;
	char						*uri;
	char						*host;
	int							port;
	struct evhttp_connection	*conn;

	struct timeval				tmp_time;
	size_t						src_size;
	uint32_t					download_time;
	uint32_t					wait_time;
	uint32_t					compress_time;
} req_t;

extern struct server_config config;
#endif

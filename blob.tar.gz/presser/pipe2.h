#ifndef __H_PIPE2_H__
#define __H_PIPE2_H__
#endif

#ifndef HAVE_PIPE2

#include <sys/syscall.h>
#include <unistd.h>

#ifndef __NR_pipe2
#define __NR_pipe2 293

int pipe2(int fds[2], int flags);

#endif

#endif

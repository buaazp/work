#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <event2/event.h>
#include <event2/http.h>
#include <event2/buffer.h>
#include <event2/dns.h>
#include <assert.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "utils.h"
#include "task.h"
#include "presser.h"
#include "worker.h"
#include "log.h"
#ifdef MEM_TRACE_ON
#include <mcheck.h>
#endif

#define MAX_QUEUE_SIZE				1024
#define QSIZE_PER_CPU				20
#define OPEN_FILE_NUM				10240

char ** presser_argv = NULL;

struct server_config config = {
	.daemon							= 0,
	.qsize							= 0,
	.timeout						= 10,
	.workers						= 0,
	.connections					= 10240,
	.requests						= 1024,
	.port							= 8888,
	.addr							= "0.0.0.0",
	.log_path						= NULL,
	.user							= NULL,
	.group							= NULL,
};

static struct server io_server;
extern struct worker_module scale_module;

void usage()
{
	printf("presser -q<qsize> -w<workers> -c<connections> -t<timeout> "
			"-u<user> -g<group> -r<requests> -l<addr> -p<port> -L<log> -d\n");
	printf("presser -h for the message\n");
	return;
}

static int get_args(int argc, char *argv[])
{
	int opt;
	long ret;

	presser_argv = (char **)argv;

	while ((opt = getopt(argc, argv, "c:dg:hl:p:q:r:t:u:w:L:")) != -1) {
		switch (opt) {
			case 'c' :
				config.connections = atoi(optarg);
				break;
			case 'd' :
				config.daemon = 1;
				break;
			case 'g' :
				config.group = strdup(optarg);
				break;
			case 'h' :
				return -1;
			case 'l' :
				config.addr = strdup(optarg);
				break;
			case 'p' :
				config.port = atoi(optarg);
				break;
			case 'q' :
				config.qsize = atoi(optarg);
				break;
			case 'r' :
				config.requests = atoi(optarg);
				break;
			case 't' :
				config.timeout = atoi(optarg);
				break;
			case 'u' :
				config.user = strdup(optarg);
				break;
			case 'w' :
				config.workers = atoi(optarg);
				break;
			case 'L' :
				config.log_path = strdup(optarg);
				break;
			default :
				return -1;
		}
	}

	ret = get_cpu_cores();
	if (ret == -1) return -1;
	config.cores = ret;
	ret = get_pagesize();
	if (ret == -1) return -1;
	config.pagesize = ret;

	return 0;
}

static int check_args()
{
	if (config.connections < 1) return -1;
	if (config.port < 1 || config.port > 0xFFFF) return -1;
	if (config.qsize > MAX_QUEUE_SIZE) return -1;
	if (config.requests < 1) return -1;

	if (config.workers == 0) {
		//config.workers = config.cores > 2 ? (config.cores - 2) : 1;
		config.workers = config.cores;
	}
	if (config.qsize == 0) config.qsize = config.cores * QSIZE_PER_CPU;

	return 0;
}

req_t * new_request()
{
	req_t *req;
	req = calloc(1, sizeof(req_t));
	return req;
}

void free_request(req_t *req)
{
	free(req);
}

static inline const char * get_req_header
(struct evhttp_request *req, const char *key)
{
	return evhttp_find_header(evhttp_request_get_input_headers(req), key);
}

static inline int check_req_arg(req_t *req)
{
	if (req->server->module->check_work_arg) {
		return req->server->module->check_work_arg(req->http_req);
	}
	return -1;
}

static inline int set_req_arg(req_t *req, tb_t *tb, void *arg)
{
	if (req->server->module->set_work_arg) {
		return req->server->module->set_work_arg(tb, req->http_req);
	}
	return -1;
}

static inline uint8_t * set_req_data
(req_t *req, tb_t *tb, void *data, size_t size)
{
	if (req->server->module->check_work_arg) {
		return req->server->module->set_work_data(tb, data, size);
	}
	return NULL;
}

static inline uint8_t * get_req_data
(req_t *req, tb_t *tb, size_t *size)
{
	if (req->server->module->check_work_arg) {
		return req->server->module->get_work_data(tb, size);
	}
	return NULL;
}

int append_to_wait_queue(req_t *req, struct evbuffer *buf, size_t size)
{
	int ret;
	uint8_t *data;
	wb_t *wb = NULL;

	wb = new_wait_block(size);
	if (wb == NULL) return -1;

	ret = set_req_arg(req, wb, NULL);
	if (ret != 0) goto hell;

	data = set_req_data(req, wb, NULL, size);
	if (data == NULL) goto hell;

	wb->arg = req;

	evbuffer_copyout(buf, data, size);
	tb_watermark(wb);

	wait_enqueue(&io_server.wait_queue, wb);

	return 0;

hell :
	if (wb != NULL) {
		free_wait_block(wb);
	}
	return -1;
}

void save_http_content(struct evhttp_request *http, void *arg)
{
	int ret;
	int code;
	size_t size;
	uint8_t *data;
	tb_t *tb = NULL;
	req_t *req = arg;
	struct evbuffer *buf = NULL;

	/* check downloading */
	if (http == NULL || req == NULL) {
		msg_log(LOG_ERROR, "none %p %p", http, req);
		goto hell;
	}
	buf = evhttp_request_get_input_buffer(http);
	size = evbuffer_get_length(buf);
	code = evhttp_request_get_response_code(http);
	if (code != 200) {
		msg_log(LOG_ERROR, "code not 2XX: %d", code);
		goto hell;
	}

	req->src_size = size;
	req->download_time = update_temp_time(&req->tmp_time);
	io_server.succ_downloads++;
	msg_log(LOG_INFO, "downloaded %s %s %zu %ums", req->host,
			evhttp_request_get_uri(http), size, req->download_time);

	/* enqueue */
	tb = new_task_block(&req->server->task_pool);
	if (tb == NULL) {
		msg_log(LOG_WARN, "task block exhausted!");

		ret = append_to_wait_queue(req, buf, size);
		if (ret == 0) return;
		goto hell;
	}

	/* set up task  */
	ret = set_req_arg(req, tb, http);
	if (ret != 0) {
		msg_log(LOG_DEBUG, "setarg");
		goto hell;
	}

	data = set_req_data(req, tb, NULL, size);
	if (data == NULL) {
		msg_log(LOG_DEBUG, "setdata");
		goto hell;
	}

	tb->arg = req;

	evbuffer_copyout(buf, data, size);
	tb_watermark(tb);

	ret = task_enqueue(req->server->worker_queue, tb);
	if (ret != 0) {
		msg_log(LOG_ERROR, "task queue is empty");
		goto hell;
	}
	msg_log(LOG_DEBUG, "sent");

	return;

hell:
	msg_log(LOG_ERROR, "failed %s %s", req->host, req->uri);
	io_server.failed_downloads++;
	if (tb != NULL) free_task_block(&req->server->task_pool, tb);
	evhttp_send_reply(req->http_req, 404, "NOT FOUND", NULL);
	io_server.connections--;
	free_request(req);
	return;
}

int download(req_t *req)
{
	int ret;
	struct evhttp_request *http;
	struct evhttp_connection *conn;

	update_temp_time(&req->tmp_time);

	http = evhttp_request_new(save_http_content, req);
	if (req == NULL) return -1;

	conn = evhttp_connection_base_new(req->server->base,
			req->server->dns, req->host, req->port);
	if (conn == NULL) {
		evhttp_request_free(http);
		return -1;
	}
	evhttp_connection_set_timeout(conn, config.timeout);

	evhttp_add_header(evhttp_request_get_output_headers(http), "host", req->host);

	ret = evhttp_make_request(conn, http, EVHTTP_REQ_GET, req->uri);
	if (ret != 0) {
		/*  the request object is no longer valid as it has been freed. */
		evhttp_connection_free(conn);
		return -1;
	}
	req->conn = conn;

	return 0;
}

static inline unsigned short get_src_port(struct evhttp_request *req)
{
	int port;
	const char *str_port;

	str_port = get_req_header(req, "src-port");
	if (str_port == NULL) return 80;
	port = atoi(str_port);
	return (port > 0 ? port : 80);
}

void http_monitor_handler(struct evhttp_request *http_req, void *arg)
{
	struct server *sv = arg;
	struct evbuffer *buf = NULL;

	buf = evbuffer_new();
	if (buf == NULL) {
		evhttp_send_reply(http_req, 500, "Internal Server Error", NULL);
		return;
	}

	evbuffer_add_printf(buf, "queue-size: %u\n", task_queue_size(sv->worker_queue));
	evbuffer_add_printf(buf, "wait-size: %u\n", wait_queue_size(&sv->wait_queue));
	evbuffer_add_printf(buf, "connections: %u\n",	sv->connections);
	evbuffer_add_printf(buf, "requests: %llu\n",	sv->requests);
	evbuffer_add_printf(buf, "failed-down: %llu\n",	sv->failed_downloads);
	evbuffer_add_printf(buf, "succed-down: %llu\n",	sv->succ_downloads);
	evbuffer_add_printf(buf, "failed-comp: %llu\n",	sv->failed_compress);
	evbuffer_add_printf(buf, "succed-comp: %llu\n",	sv->succ_compress);
	evhttp_send_reply(http_req, 200, "OK", buf);
	return;
}

void http_req_handler(struct evhttp_request *http_req, void *arg)
{
	int ret;
	req_t *req;
	int port;
	char *uri, *host;
	struct server *sv = arg;

	uri = (char *)evhttp_request_get_uri(http_req);
	host = (char *)evhttp_request_get_host(http_req);
	port = get_src_port(http_req);

	req = new_request();
	if (req == NULL) {
		msg_log(LOG_ERROR, "create request failed");
		evhttp_send_reply(http_req, 500, "Internal Server Error", NULL);
		return;
	}

	req->server		= arg;
	req->http_req	= http_req;
	req->uri		= uri;
	req->host		= host;
	req->port		= port;

	sv->connections++;
	sv->requests++;

	ret = check_req_arg(req);
	if (ret != 0) {
		msg_log(LOG_ERROR, "bad request %s %s", evhttp_request_get_host(http_req),
				evhttp_request_get_uri(http_req));
		sv->connections--;
		free_request(req);
		evhttp_send_reply(http_req, 400, "Bad Request", NULL);
		return;
	}

	/********************************************
	 * call route:
	 * download -> svae_http_content -> compress
	 *
	 ********************************************/
	// TODO: rename function download
	msg_log(LOG_DEBUG, "start download %s %s %d %d", req->host, req->uri,
			io_server.worker_queue->size, io_server.output_queue->size,
			io_server.wait_queue.size);
	ret = download(req);
	if (ret != 0) {
		msg_log(LOG_ERROR, "bad request %s %s", evhttp_request_get_host(http_req),
				evhttp_request_get_uri(http_req));
		sv->connections--;
		free_request(req);
		evhttp_send_reply(http_req, 500, "Internal Server Error", NULL);
		return;
	}

	return;
}

void process_wait_queue(struct server *sv)
{
	int ret;
	wb_t *wb;
	tb_t *tb;

	while (!wait_empty(&sv->wait_queue)) {
		tb = new_task_block(&sv->task_pool);
		if (tb == NULL) return;

		wb = wait_dequeue(&sv->wait_queue);
		if (wb == NULL) {
			free_task_block(&sv->task_pool, tb);
			return;
		}

		memcpy(tb, wb, sizeof_wait_block(wb));

		ret = task_enqueue(sv->worker_queue, tb);
		if (ret == 0) {
			free_wait_block(wb);
		} else {
			wait_enqueue(&sv->wait_queue, wb);
			free_task_block(&sv->task_pool, tb);
		}
	}

	return;
}

void output_task(tb_t *tb)
{
	int ret;
	assert(tb != NULL);
	req_t *req = tb->arg;
	assert(req != NULL);
	struct server *sv = req->server;
	assert(sv != NULL);
	struct evhttp_request *http = req->http_req;
	assert(http != NULL);
	struct evbuffer *buf;

	if (tb->code == TS_OK) {
		ret = tb_check_watermaker(tb);
		if (!ret) goto hell;

		uint8_t *data;
		size_t size;
		data = get_req_data(req, tb, &size);
		if (data == NULL) goto hell;

		/* copy out */
		buf = evbuffer_new();
		if (buf == NULL) goto hell;

		ret = evbuffer_add(buf, data, size);
		if (ret != 0) {
			evbuffer_free(buf);
			goto hell;
		}

		evhttp_send_reply(http, 200, "OK", buf);
		evbuffer_free(buf);

		sv->succ_compress++;
		req->compress_time = tb->elapsed;
		req->wait_time = update_temp_time(&req->tmp_time) - tb->elapsed;

		msg_log(LOG_INFO, "compressed %s %s SRC:%zu DST:%zu D:%ums C:%ums W:%ums",
				req->host, evhttp_request_get_uri(http), req->src_size, size,
				req->download_time, req->compress_time, req->wait_time);
		goto fin;
	}

hell:
	msg_log(LOG_DEBUG, "notsucc");
	sv->failed_compress++;
	evhttp_send_reply(http, 500, "Internal Server Error", NULL);
fin:
	//free tb
	free_task_block(&sv->task_pool, tb);
	if (req->conn != NULL) {
		evhttp_connection_free(req->conn);
		req->conn = NULL;
	}
	sv->connections--;
	free_request(req);

	process_wait_queue(&io_server);

#ifdef MEM_TRACE_ON
	muntrace();
#endif
	return;
}

int spawn_worker(struct server *sv, wi_t *info);

int start_workers(struct server *sv, int n)
{
	wi_t *info;
	int i, ret, succ=0;

	sv->worker_list = shm_alloc(sizeof(wi_t) * n);
	if (sv->worker_list == NULL) return 0;

	info = sv->worker_list;
	for (i=0; i<n; i++, info++) {
		ret = spawn_worker(sv, info);
		if (ret == 0) succ++;
	}

	return succ;
}

static int exit_signals[] = { 
	SIGTERM, SIGINT, SIGALRM, SIGHUP, SIGKILL, SIGPIPE,
	SIGABRT, SIGFPE, SIGILL, SIGQUIT, SIGSEGV, SIGTRAP,
	SIGSYS, SIGBUS, SIGXCPU, SIGXFSZ, 0
};

void stop_server(int sig)
{
	int i;

	/* disable child signal */
	signal(SIGCHLD, SIG_IGN);

	for (i=0; i<config.workers; i++) {
		admin_worker(io_server.worker_list+i, CMD_STOP_WORKER);
	}

	msg_log(LOG_INFO, "server stoped");
	exit(0);
}

void cut_log(int sig)
{
	int ret;

	if (sig != SIGUSR1) return;
	if (config.log_path == NULL) return;

	ret = reopen_log(config.log_path);
	if (ret != 0) {
		printf("reopen log <%s> failed\n", config.log_path);
		return;
	}

	/*
	int i;
	for (i=0; i<config.workers; i++) {
		admin_worker(io_server.worker_list+i, CMD_REOPEN_LOG);
	}
	*/

	return;
}

void respawn_worker(int sig)
{
	pid_t pid;
	int ret, i, status;
	wi_t *p = io_server.worker_list;

	if (sig != SIGCHLD) return;
	if (io_server.worker_list == NULL) return;

	for (i=0; i<config.workers; i++, p++) {
		pid = waitpid(p->pid, &status, WNOHANG);
		if (pid < 1) continue;
		if (p->task != NULL) {
			p->task->code = TS_FAILED;
			output_task(p->task);
			p->task = NULL;
		}
		ret = spawn_worker(&io_server, p);
		if (ret != 0) {
			msg_log(LOG_ERROR, "spawn worker failed");
		}
		msg_log(LOG_DEBUG, "new worker respawned %d", p->pid);
	}
}

void worker_manager(int fd, short what, void *arg)
{
	respawn_worker(SIGCHLD);
}

void init_signal()
{
	int i;
	struct sigaction act;

	memset(&act, 0, sizeof(struct sigaction));
	sigfillset(&act.sa_mask);

	act.sa_handler = stop_server;

	for (i=0; exit_signals[i]; i++) {
		sigaction(exit_signals[i], &act, NULL);
	}   

	signal(SIGUSR1, cut_log);
	//signal(SIGCHLD, respawn_worker);
}


int start_server()
{
	int ret;

	io_server.module = &scale_module;

	io_server.base = event_base_new();
	if (io_server.base == NULL) return -1;
	io_server.dns = evdns_base_new(io_server.base, 1);
	if (io_server.dns == NULL) return -1;

	/* setup server */
	ret = init_task_pool(&io_server.task_pool, config.qsize);
	if (ret != 0) {
		msg_log(LOG_ERROR, "init task pool failed: %u", config.qsize);
		return -1;
	}

	io_server.worker_queue = new_task_queue();
	if (io_server.worker_queue == NULL) {
		msg_log(LOG_ERROR, "create worker queue failed");
		return -1;
	}
	io_server.output_queue = new_task_queue();
	if (io_server.output_queue == NULL) {
		msg_log(LOG_ERROR, "create output queue failed");
		return -1;
	}
	/* setup task event */
	ret = task_queue_set_callback(io_server.output_queue,
			io_server.base, output_task);

	init_wait_queue(&io_server.wait_queue);

	/* start  http server */
	io_server.http = evhttp_new(io_server.base);
	if (io_server.http == NULL) return -1;
	/* monitor interface */
	evhttp_set_cb(io_server.http, "/monitor", http_monitor_handler, &io_server);
	/* http callback */
	evhttp_set_gencb(io_server.http, http_req_handler, &io_server);

	ret = evhttp_bind_socket(io_server.http, config.addr, config.port);
	if (ret != 0) {
		msg_log(LOG_ERROR, "listen on socket %s:%u failed",
				config.addr, config.port);
		return -1;
	}

	/* start workers */
	init_signal();

	/* worker manager */
	struct event *sevt;
	sevt = evsignal_new(io_server.base, SIGCHLD, worker_manager, NULL);
	if (sevt == NULL) {
		msg_log(LOG_ERROR, "set worker_manager failed");
		return -1;
	}
	event_add(sevt, NULL);

	ret = start_workers(&io_server, config.workers);
	if (ret == 0) {
		msg_log(LOG_ERROR, "start workers failed");
		return -1;
	}
	msg_log(LOG_INFO, "%d workers started", ret);

#ifdef MEM_TRACE_ON
	mtrace();
#endif
	event_base_dispatch(io_server.base);

	/* never comes to here */
	return 0;
}

int main(int argc, char *argv[])
{
	int ret;

	ret = get_args(argc, argv);
	if (ret == -1) {
		usage();
		return 1;
	}

	ret = check_args();
	if (ret == -1) {
		usage();
		return 1;
	}

	ret = set_rlimits(RLIMIT_NOFILE, OPEN_FILE_NUM);
	if (ret != 0) {
		fprintf(stderr, "reset rlimit failed\n");
		return -1;
	}

	//change user
	ret = set_user(config.user, config.group);
	if (ret != 0) {
		fprintf(stderr, "change user failed\n");
		return 1;
	}

	if (config.log_path != NULL) {
		ret = open_log(config.log_path);
		if (ret != 0) {
			fprintf(stderr, "open log <%s> failed", config.log_path);
			return 1;
		}
	}

	if (config.daemon) {
		daemon(1, 1);
	}


	ret = start_server();
	return ret;
}

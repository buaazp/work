#include <stdio.h>
#include <time.h>
#include <event2/event.h>
#include "log.h"

#define MAX_MSG_LEN				512
#define MAX_TIME_LEN			32

static FILE * log = NULL;

int open_log(char *path)
{
	log = freopen(path, "a", stdout);
	if (log) setlinebuf(log);
	return (log == NULL ? -1 : 0);
}

void close_log()
{
	if (log != NULL) fclose(log);
}

int reopen_log(char *path)
{
	close_log();
	return open_log(path);
}

void flush_log()
{
	fflush(log);
}

void local_timestr(time_t ts, char *str, size_t n)
{
	time_t now;
	struct tm tm; 

	now = (ts > 0) ? ts : time(NULL);
	localtime_r(&now, &tm);
	strftime(str, n, "%d/%b/%Y:%T %z", &tm);
}

void msg_log(int level, const char *msg, ...)
{
	va_list ap;
	char fmt[MAX_MSG_LEN];
	char ts[MAX_TIME_LEN];

	local_timestr(0, ts, MAX_TIME_LEN);

	switch (level) {
		case LOG_ERROR :
			snprintf(fmt, MAX_MSG_LEN, "[ERROR] [%s] %s\n", ts, msg);
			break;
		case LOG_WARN :
			snprintf(fmt, MAX_MSG_LEN, "[WARN] [%s] %s\n", ts, msg);
			break;
#ifdef DEBUG
		case LOG_DEBUG :
			snprintf(fmt, MAX_MSG_LEN, "[DEBUG] [%s] %s\n", ts, msg);
			break;
#endif
		case LOG_INFO :
			snprintf(fmt, MAX_MSG_LEN, "[INFO] [%s] %s\n", ts, msg);
			break;
		default :
			return;
	}

	va_start(ap, msg);
	log != NULL ? vfprintf(log, fmt, ap) : vprintf(fmt, ap);
	va_end(ap);
}

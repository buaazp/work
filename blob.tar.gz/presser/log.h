#ifndef __H_LOG_H__
#define __H_LOG_H__

enum log_level {
	LOG_INFO,
	LOG_ERROR,
	LOG_WARN,
	LOG_DEBUG,
};

int open_log(char *path);
int reopen_log(char *path);
void close_log();
void flush_log();
void msg_log(int, const char *, ...);
void msg_log(int level, const char *msg, ...);

#endif

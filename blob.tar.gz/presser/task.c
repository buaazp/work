#include <unistd.h>
#include <stdint.h>
#include <pthread.h>
#include <fcntl.h>

#ifdef USE_EVENTFD
#include <sys/eventfd.h>
#endif

#include <event2/event.h>

#ifndef HAVE_PIPE2
#include "pipe2.h"
#endif

#include "task.h"

int init_task_pool(tp_t *pool, int n)
{
	int i;
	void *p;
	tb_t *tbp;

	/* alloc shared memory for task blocks */
	pool->size = n * TASK_BLOCK_SIZE;
	pool->data = shm_alloc(pool->size);
	if (pool->data == NULL) return -1;

	/* init free list */
	STAILQ_INIT(&pool->free_list);
	p = pool->data;
	for (i=0; i<n; i++) {
		tbp = p;
		STAILQ_INSERT_TAIL(&pool->free_list, tbp, tbqe);
		p += TASK_BLOCK_SIZE;
	}

	return 0;
}

int destroy_task_pool(tp_t *pool)
{
	int ret;
	if (pool->data && pool->size > 0) {
		ret = shm_free(pool->data, pool->size);
		if (ret == -1) return -1;
	}

	pool->data = NULL;
	pool->size = 0;
	STAILQ_INIT(&pool->free_list);
	return 0;
}

int init_task_queue(tq_t *tq)
{
	pthread_mutexattr_t mattr;
	pthread_mutexattr_init(&mattr);
	pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED);
	pthread_mutex_init(&tq->lock, &mattr);	// always return 0

	STAILQ_INIT(&tq->queue);

#ifdef USE_EVENTFD
	tq->evfd = eventfd(0, EFD_SEMAPHORE|EFD_NONBLOCK);
	if (tq->evfd == -1) return -1;
#else
	int ret = pipe2(tq->pipe, O_NONBLOCK);
	if (ret != 0) return -1;
#endif
	tq->callback = NULL;
	tq->size = 0;

	return 0;
}

void free_task_queue(tq_t *tq)
{
	shm_free(tq, sizeof(tq_t));
}

tq_t * new_task_queue()
{
	int ret;
	tq_t *tq;

	tq = shm_alloc(sizeof(tq_t));
	if (tq != NULL) {
		ret = init_task_queue(tq);
		if (ret != 0) free_task_queue(tq);
	}

	return tq;
}

static void task_queue_callback(int fd, short what, void *arg)
{
	tb_t *tb;
	tq_t *tq = arg;

	if (tq->callback == NULL) return;
	tb = try_fetch_task(tq);
	if (tb) tq->callback(tb);
	return;
}

int task_queue_set_callback(tq_t *tq, struct event_base *base, tq_callback_t cb)
{
	int ret;
	struct event *ev;
#ifdef USE_EVENTFD
	ev = event_new(base, tq->evfd, EV_READ|EV_PERSIST, task_queue_callback, tq);
#else
	ev = event_new(base, tq->pipe[0], EV_READ|EV_PERSIST, task_queue_callback, tq);
#endif
	if (ev == NULL) return -1;
	tq->callback = cb;

	ret = event_add(ev, NULL);
	if (ret != 0) event_free(ev);
	return ret;
}

int task_enqueue(tq_t *tq, tb_t *tb)
{
	int ret;

	ret = pthread_mutex_lock(&tq->lock);
	if (ret != 0) return -1;

	STAILQ_INSERT_TAIL(&tq->queue, tb, tbqe);
	tq->size += 1;

	pthread_mutex_unlock(&tq->lock);

	/* wake up consumer */
	uint64_t buf = 1;
#ifdef USE_EVENTFD
	write(tq->evfd, &buf, sizeof(uint64_t));
#else
	write(tq->pipe[1], &buf, sizeof(uint64_t));
#endif
	/* no care of return of writting */

	return 0;
}

tb_t * task_dequeue(tq_t *tq)
{
	int ret;
	tb_t *tb = NULL;

	ret = pthread_mutex_lock(&tq->lock);
	if (ret == 0) {
		if (!STAILQ_EMPTY(&tq->queue)) {
			tb = STAILQ_FIRST(&tq->queue);
			STAILQ_REMOVE_HEAD(&tq->queue, tbqe);
			tq->size -= 1;
		}
		pthread_mutex_unlock(&tq->lock);
	}

	return tb;
}

tb_t * try_fetch_task(tq_t *tq)
{
	ssize_t ret;
	uint64_t num = 0;
	tb_t * tb = NULL;

#ifdef USE_EVENTFD
	ret = read(tq->evfd, (char *)&num, sizeof(uint64_t));
#else
	ret = read(tq->pipe[0], (char *)&num, sizeof(uint64_t));
#endif
	if (ret != sizeof(uint64_t)) return NULL;

	if (num > 0) {
		tb = task_dequeue(tq);
	}
	return tb;
}

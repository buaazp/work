#ifndef				__H_INTERNAL_H__
#define				__H_INTERNAL_H__
#include <stdint.h>
#include <sys/mman.h>
#include <pthread.h>
#include <event2/event.h>
#include "queue.h"

#define TS_OK			0
#define TS_FAILED		-1

#define TB_MAGIC		0xaaaaaaaa

#define TASK_BLOCK_SIZE			5242880
#define TASK_DATA_SIZE			(TASK_BLOCK_SIZE - sizeof(tb_t) - sizeof(uint32_t))

typedef struct task_block {
	/* request */
	int							code;
	int							refcnt;
	/* task block queue entry */
	STAILQ_ENTRY(task_block)	tbqe;
	uint32_t					elapsed;
	uint32_t					size;
	void						*arg;
	uint8_t						data[0];		//data
} tb_t;

typedef void(*tq_callback_t)(tb_t *);

typedef struct task_queue {
	uint32_t						size;
#ifdef USE_EVENTFD
	int								evfd;
#else
	int								pipe[2];
#endif
	pthread_mutex_t					lock;
	STAILQ_HEAD(, task_block)		queue;
	tq_callback_t					callback;
} tq_t;

typedef struct task_pook {
	size_t						size;
	void						*data;
	STAILQ_HEAD(, task_block)	free_list;
} tp_t;

int init_task_pool(tp_t *pool, int n);

static inline void tb_watermark(tb_t *tb)
{
	uint32_t *p;
	p = (uint32_t *)(tb->data + tb->size);
	*p = TB_MAGIC;
}

static inline int tb_check_watermaker(tb_t *tb)
{
	uint32_t *p;
	p = (uint32_t *)(tb->data + tb->size);

	return (*p == TB_MAGIC);
}

static inline tb_t * new_task_block(tp_t *pool)
{
	tb_t *tb = NULL;

	if (!STAILQ_EMPTY(&pool->free_list)) {
		tb = STAILQ_FIRST(&pool->free_list);
		STAILQ_REMOVE_HEAD(&pool->free_list, tbqe);
	}
	return tb;
}

static inline void free_task_block(tp_t *pool, tb_t *tb)
{
	if (tb) {
		STAILQ_INSERT_HEAD(&pool->free_list, tb, tbqe);
	}
}

tq_t * new_task_queue();
void free_task_queue(tq_t *tq);
tb_t * try_fetch_task(tq_t *tq);
int task_enqueue(tq_t *tq, tb_t *tb);
int task_queue_set_callback(tq_t *, struct event_base *, tq_callback_t);

static inline uint32_t task_queue_size(tq_t *tq)
{
	/* since writes to tq->size are protected by mutex,
	   pthread_mutex_lock is not nessary here */
	return (tq->size);
}

static inline void * shm_alloc(size_t size)
{
	void *p;

	p = mmap(NULL, size,
			PROT_WRITE|PROT_READ, MAP_SHARED|MAP_ANONYMOUS, -1, 0);
	return (p == MAP_FAILED ? NULL : p);
}

static inline int shm_free(void *p, size_t size)
{
	return munmap(p, size);
}
#endif

#include "pipe2.h"

#ifndef HAVE_PIPE2

#ifdef USE_SYSCALL
int pipe2(int fds[2], int flags)
{
	return (syscall(__NR_pipe2, fds, flags));
}
#else
#include <unistd.h>
#include <fcntl.h>
int setup_fd(int fd, int flags)
{
	int ret;

	ret = fcntl(fd, F_GETFL, NULL);
	if (ret == -1) return -1; 

	ret = fcntl(fd, F_SETFL, ret|flags);
	if (ret == -1) return -1; 

	return 0;
}

int pipe2(int fds[2], int flags)
{
	int ret;

	ret = pipe(fds);
	if (ret != 0) return -1; 

	ret = setup_fd(fds[0], flags);
	if (ret != 0) return -1; 
	ret = setup_fd(fds[1], flags);
	if (ret != 0) return -1; 

	return 0;
}
#endif

#endif

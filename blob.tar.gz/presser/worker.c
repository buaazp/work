#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <fcntl.h>
#include <signal.h>
#include <event2/event.h>
#include <sys/time.h>
#include "presser.h"
#include "worker.h"
#include "task.h"
#include "utils.h"
#include "log.h"

#ifndef HAVE_PIPE2
#include "pipe2.h"
#endif

#define MAX_REQUESTS			1024

/*
 * tow queues:
 *		task queue for transmitting tasks
 *		output queue for transmitting outputs
 */


static struct worker_stat {
	int							stop;
	uint32_t					reqs;
	struct server				*server;
	wi_t						*info;

	/* base */
	struct event_base			*base;
	struct event				*ev;
} worker;

void clear_worker();
void exit_worker();

void do_work(tb_t *tb)
{
	int ret;
	struct timeval start, stop;
	assert(tb != NULL);

	/* save task block */
	worker.info->task = tb;

	gettimeofday(&start, NULL);
	ret = worker.server->module->mod_handle(tb);
	gettimeofday(&stop, NULL);
	tb->elapsed = calc_elapse(&start, &stop);

	tb->code = ret == 0 ? TS_OK : TS_FAILED;

	/* output */
	ret = task_enqueue(worker.server->output_queue, tb);
	if (ret == 0) {
		worker.info->task = NULL;
	} else {
		exit_worker();
	}

	/*
	if (MAX_REQUESTS > 0 && worker.reqs++ >= MAX_REQUESTS) {
		worker.stop = 1;
	}
	*/
	if (config.requests > 0 && worker.reqs++ >= config.requests) {
		worker.stop = 1;
	}
	if (worker.stop) {
		exit_worker();
	}


	return;
}

void admin_worker_handler(int fd, short what, void *arg)
{
	ssize_t ret;
	uint64_t buf;

	ret = read(fd, &buf, sizeof(uint64_t));
	if (ret != sizeof(uint64_t)) return;

	switch (buf) {
		case CMD_STOP_WORKER :
			worker.stop = 1;
			exit_worker();
			break;
		case CMD_REOPEN_LOG :
			if (config.log_path != NULL) {
				reopen_log(config.log_path);
			}
			break;
	}

	return;
}

int admin_worker(wi_t *info, int cmd)
{
	ssize_t ret;
	uint64_t buf = cmd;

	ret = write(info->pipe[1], &buf, sizeof(uint64_t));
	return (ret == sizeof(uint64_t) ? 0 : -1);
}

void sig_exit(int sig)
{
	exit_worker();
	exit(0);
}


int start_worker(struct server *sv, wi_t *info)
{
	int ret;

	worker.stop			= 0;
	worker.reqs			= 0;
	worker.server		= sv;
	worker.info			= info;
	worker.ev			= NULL;
	worker.base			= NULL;

	signal(SIGINT,		sig_exit);
	signal(SIGKILL,		sig_exit);
	signal(SIGTERM,		sig_exit);
	signal(SIGABRT,		sig_exit);
	signal(SIGSEGV,		sig_exit);
	signal(SIGCHLD,		SIG_IGN);

	/* start main loop */
	worker.base = event_base_new();
	if (worker.base == NULL) return -1;

	/* regist admin event */
	worker.ev = event_new(worker.base, info->pipe[0],
			EV_READ|EV_PERSIST, admin_worker_handler, NULL);
	if (worker.ev == NULL) {
		clear_worker();
		return -1;
	}
	event_add(worker.ev, NULL);

	/* regist worker handler */
	ret = task_queue_set_callback(sv->worker_queue, worker.base, do_work);
	if (ret != 0) {
		clear_worker();
		return -1;
	}

	/* go */
	ret = event_base_dispatch(worker.base);
	if (ret != 0) {
		clear_worker();
		return -1;
	}

	return 0;
}

void clear_worker()
{
	if (worker.ev != NULL) {
		event_free(worker.ev);
	}
	if (worker.base != NULL) {
		event_base_free(worker.base);
	}

	close(worker.info->pipe[0]);
	worker.base = NULL;
	worker.ev = NULL;
}

void exit_worker()
{
	clear_worker();
	exit(0);
}

extern char ** presser_argv;

int spawn_worker(struct server *sv, wi_t *info)
{
	int ret;
	pid_t pid;

	/* admin pipe */
	ret = pipe2(info->pipe, O_NONBLOCK);
	if (ret != 0) return -1;

	pid = fork();
	switch (pid) {
		case -1 :
			close(info->pipe[0]);
			close(info->pipe[1]);
			return -1;
		case 0 :
			close(info->pipe[1]);
			ret = set_proctitle(presser_argv, "presser: worker");
			ret = start_worker(sv, info);
			return ret;
		default :
			close(info->pipe[0]);
			info->pid = pid;
	}

	return 0;
}

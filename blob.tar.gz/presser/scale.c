#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <webimg2.h>
#include <event2/http.h>
#include "task.h"
#include "worker.h"

static inline uint32_t max(uint32_t x, uint32_t y)
{
	return (x > y ? x : y);
}

static inline uint32_t min(uint32_t x, uint32_t y)
{
	return (x < y ? x : y);
}

typedef enum {
	C_OK			= 0,
	E_LOAD,
} status;

typedef enum {
	CT_SQUARE,
	CT_MAX_WIDTH,
	CT_MAX_SIZE,
	CT_PROPORTION,
	CT_CROP,
	CT_NONE,
} conv_type;

typedef enum {
	CF_JPEG,
	CF_PNG,
	CF_GIF,
	CF_WEBP,
} conv_format;

struct con_arg {
	char			*name;
	int				type;
	uint32_t		size;
	float			ratio;
	uint32_t		x;
	uint32_t		y;
	uint32_t		cols;
	uint32_t		rows;
	uint32_t		cl;
	int				quality;
	int				interlace;
	conv_format		format;
};

struct scale_arg {
	int				type;
	uint32_t		x;
	uint32_t		y;
	uint32_t		cols;
	uint32_t		rows;
	uint32_t		cl;
	size_t			size;
	uint8_t			data[0];
};

#define WAP_QUALITY				70
#define THUMB_QUALITY			85
#define QUALITY_90				90
#define QUALITY_95				95

static struct con_arg type_list[] = 
{
	{
		.name				= "woriginal",
		.type				= CT_NONE,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "mw2048",
		.type				= CT_NONE,
		.quality			= WAP_QUALITY,
		.interlace			= 1,
	},
	{
		.name				= "thumb30",
		.type				= CT_SQUARE,
		.size				= 30,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "thumb50",
		.type				= CT_SQUARE,
		.size				= 50,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "thumb150",
		.type				= CT_SQUARE,
		.size				= 150,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "thumb180",
		.type				= CT_SQUARE,
		.size				= 180,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "thumb300",
		.type				= CT_SQUARE,
		.size				= 300,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "square",
		.type				= CT_SQUARE,
		.size				= 80,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "cover",
		.type				= CT_SQUARE,
		.size				= 200,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "sq612",
		.type				= CT_SQUARE,
		.size				= 612,
		.quality			= QUALITY_90,
	},
	{
		.name				= "thumbnail",
		.type				= CT_MAX_SIZE,
		.size				= 120,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "ms160",
		.type				= CT_MAX_SIZE,
		.size				= 160,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "small",
		.type				= CT_MAX_SIZE,
		.size				= 200,
		.quality			= THUMB_QUALITY,
		.ratio				= 3.0/10,
	},
	{
		.name				= "bmiddle",
		.type				= CT_MAX_WIDTH,
		.size				= 440,
		.quality			= QUALITY_90,
	},
	{
		.name				= "mw1024",
		.type				= CT_MAX_WIDTH,
		.size				= 1024,
		.quality			= QUALITY_95,
		.interlace			= 1,
	},
	{
		.name				= "mw720",
		.type				= CT_MAX_WIDTH,
		.size				= 720,
		.quality			= THUMB_QUALITY,
		.interlace			= 1,
	},
	{
		.name				= "mw600",
		.type				= CT_MAX_WIDTH,
		.size				= 600,
		.quality			= QUALITY_95,
	},
	{
		.name				= "mw690",
		.type				= CT_MAX_WIDTH,
		.size				= 690,
		.quality			= QUALITY_95,
		.interlace			= 1,
	},
	{
		.name				= "mw220",
		.type				= CT_MAX_WIDTH,
		.size				= 220,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "mw240",
		.type				= CT_MAX_WIDTH,
		.size				= 240,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "mw205",
		.type				= CT_MAX_WIDTH,
		.size				= 205,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "large",
		.type				= CT_MAX_WIDTH,
		.size				= 2048,
		.quality			= QUALITY_95,
	},
	{
		.name				= "wap720",
		.type				= CT_MAX_WIDTH,
		.size				= 720,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "ms080",
		.type				= CT_MAX_SIZE,
		.size				= 80,
		.quality			= THUMB_QUALITY,
	},
	{
		.name				= "wap800",
		.type				= CT_MAX_SIZE,
		.size				= 800,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap690",
		.type				= CT_MAX_SIZE,
		.size				= 690,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap35",
		.type				= CT_MAX_SIZE,
		.size				= 35,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap50",
		.type				= CT_MAX_SIZE,
		.size				= 50,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap120",
		.type				= CT_MAX_SIZE,
		.size				= 120,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap360",
		.type				= CT_MAX_SIZE,
		.size				= 360,
		.ratio				= 3.0/10,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap180",
		.type				= CT_MAX_SIZE,
		.size				= 180,
		.ratio				= 3.0/10,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap128",
		.type				= CT_PROPORTION,
		.cols				= 128,
		.rows				= 160,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap176",
		.type				= CT_PROPORTION,
		.cols				= 176,
		.rows				= 220,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap240",
		.type				= CT_PROPORTION,
		.cols				= 240,
		.rows				= 320,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "wap320",
		.type				= CT_PROPORTION,
		.cols				= 320,
		.rows				= 480,
		.quality			= WAP_QUALITY,
	},
	{
		.name				= "webp720",
		.type				= CT_MAX_WIDTH,
		.size				= 720,
		.quality			= WAP_QUALITY,
		.format				= CF_WEBP,
	},
	{
		.name				= "webp440",
		.type				= CT_MAX_WIDTH,
		.size				= 440,
		.quality			= QUALITY_90,
		.format				= CF_WEBP,
	},
	{
		.name				= "webp360",
		.type				= CT_MAX_SIZE,
		.size				= 360,
		.ratio				= 3.0/10,
		.quality			= WAP_QUALITY,
		.format				= CF_WEBP,
	},
	{
		.name				= "webp180",
		.type				= CT_MAX_SIZE,
		.size				= 180,
		.ratio				= 3.0/10,
		.quality			= WAP_QUALITY,
		.format				= CF_WEBP,
	},
	{
		.name				= "crop",
		.type				= CT_CROP,
		.quality			= QUALITY_90,
	},
};

struct con_arg * choose_type(char *name)
{
	struct con_arg *arg = type_list;

	while (arg->name != NULL) {
		if (strcmp(name, arg->name) == 0) return arg;
	}

	return NULL;
}

/* worker control block */
struct wcb {
	int				id;
	uint8_t			*data;
	uint32_t		size;
	struct con_arg	*arg;
};

static int square(struct image *im, uint32_t size)
{
	int ret;
	uint32_t x, y, cols;

	if (im->cols > im->rows) {
		cols = im->rows;
		y = 0;
		x = (uint32_t)floor((im->cols - im->rows) / 2.0);
	} else {
		cols = im->cols;
		x = 0;
		y = (uint32_t)floor((im->rows - im->cols) / 2.0);
	}

	ret = wi_crop(im, x, y, cols, cols);
	if (ret != WI_OK) return -1;

	ret = wi_scale(im, size, 0);
	if (ret != WI_OK) return -1;

	return 0;
}

static int max_width(struct image *im, struct con_arg *arg)
{
	int ret;
	float ratio;
	uint32_t rows, cols;

	if (im->cols <= arg->size) return 0;

	cols = arg->size;
	if (arg->ratio > 0.0) {
		ratio = (float)im->cols / im->rows;
		if (ratio < arg->ratio) {
			cols = im->cols;
			rows = floor(cols / arg->ratio);
			if (rows > im->rows) rows = im->rows;

			ret = wi_crop(im, 0, 0, cols, rows);
			if (ret != WI_OK) return -1;
		} else {
			cols = min(arg->size, im->cols);
			rows = im->rows;

			ret = wi_crop(im, 0, 0, cols, rows);
			return (ret == WI_OK) ? 0 : -1;
		}
	}

	ret = wi_scale(im, cols, 0);
	return (ret == WI_OK) ? 0 : -1;
}

static int max_size(struct image *im, struct con_arg *arg)
{
	int ret;
	float ratio;
	uint32_t rows, cols;

	if (im->cols <= arg->size && im->rows <= arg->size) return 0;

	if (arg->ratio > 0.0) {
		ratio = (float)im->cols / im->rows;
		if (im->cols < (arg->size * arg->ratio) && ratio < arg->ratio) {
			cols = im->cols;
			rows = min(im->rows, arg->size);

			ret = wi_crop(im, 0, 0, cols, rows);
			return (ret == WI_OK) ? 0 : -1;
		}
		if (im->rows < (arg->size * arg->ratio) && ratio > (1.0/arg->ratio)) {
			rows = im->rows;
			cols = min(im->cols, arg->size);

			ret = wi_crop(im, 0, 0, cols, rows);
			return (ret == WI_OK) ? 0 : -1;
		}

		if (im->cols > im->rows && ratio > (1.0/arg->ratio)) {
			rows = im->rows;
			cols = rows / arg->ratio;
			if (cols > im->cols) cols = im->cols;

			ret = wi_crop(im, 0, 0, cols, rows);
			if (ret != WI_OK) return -1;
		} else if (ratio < arg->ratio) {
			cols = im->cols;
			rows = cols / arg->ratio;
			if (rows > im->rows) rows = im->rows;

			ret = wi_crop(im, 0, 0, cols, rows);
			if (ret != WI_OK) return -1;
		}
	}

	if (im->cols > im->rows) {
		cols = arg->size;
		rows = 0;
	} else {
		rows = arg->size;
		cols = 0;
	}
	ret = wi_scale(im, cols, rows);
	return (ret == WI_OK) ? 0 : -1;
}

static int proportion(struct image *im, struct con_arg *arg)
{
	int ret;
	float ratio;
	uint32_t cols, rows;

	ratio = im->cols / im->rows;
	if (ratio > arg->ratio) {
		cols = arg->cols;
		if (im->cols < cols) return 0;
		rows = 0;
	} else {
		rows = arg->rows;
		if (im->rows < rows) return 0;
		cols = 0;
	}

	ret = wi_scale(im, cols, rows);
	return (ret == WI_OK) ? 0 : -1;
}

static int crop(struct image *im, struct scale_arg *arg)
{
	int ret;

	ret = wi_crop(im, arg->x, arg->y, arg->cols, arg->rows);
	if (ret != WI_OK) return -1;

	if (arg->cl > 0 && arg->cl < im->cols) {
		ret = wi_scale(im, arg->cl, 0);
		if (ret != WI_OK) return -1;
	}
	return 0;
}

uint8_t * set_work_data(tb_t *tb, void * data, size_t size);
static void output(tb_t *tb, struct image *im, int succ)
{
	size_t size;
	uint8_t *data;
	uint8_t *rdata;

	if (succ) {
		if (im->converted) {
			data = wi_get_blob(im, &size);
			if (data != NULL) {
				rdata= set_work_data(tb, data, size);
				if (rdata != NULL) {
					tb->code = TS_OK;
					tb_watermark(tb);
					return;
				}
			}
		} else {
			tb->code = TS_OK;
			return;
		}
	}

	tb->code = TS_FAILED;
	return;
}

int convert(tb_t *tb)
{
	int ret;
	struct image *im;

	struct scale_arg *sarg = (struct scale_arg *)tb->data;
	struct con_arg *arg = &type_list[sarg->type];

	im = wi_new_image();
	if (im == NULL) return -1;

	ret = wi_read_blob(im, sarg->data, sarg->size);
	if (ret != WI_OK) goto failed;

	switch (arg->type) {
		case CT_SQUARE :
			ret = square(im, arg->size);
			break;

		case CT_MAX_WIDTH :
			ret = max_width(im, arg);
			break;

		case CT_MAX_SIZE :
			ret = max_size(im, arg);
			break;

		case CT_PROPORTION :
			ret = proportion(im, arg);
			break;

		case CT_CROP :
			ret = crop(im, sarg);
			break;

		case CT_NONE :
			ret = WI_OK;
			break;

		default :
			goto failed;
	}

	if (ret != WI_OK) goto failed;

	/* set quality */
	if (im->quality > arg->quality) {
		wi_set_quality(im, arg->quality);
	}

	if (im->interlace) {
	}

	/* set format */
	ret = WI_OK;
	if (arg->format == CF_PNG) {
		ret = wi_set_format(im, "JPEG");
	}
	if (arg->format == CF_WEBP && arg->format != CF_GIF) {
		ret = wi_set_format(im, "WEBP");
	}
	if (ret != WI_OK) goto failed;

	/* output */
	output(tb, im, 1);

	wi_free_image(im);
	return 0;

failed :
	output(tb, im, 0);
	wi_free_image(im);
	return -1;
}

static inline const char * get_req_header
(struct evhttp_request *req, const char *key)
{
	return evhttp_find_header(evhttp_request_get_input_headers(req), key);
}

int get_scale_code(const char *rtype)
{
	int i, n;
	struct con_arg *p;
	char *idx;
	char type[128];

	if (rtype == NULL) return 0;

	strncpy(type, rtype, 128);
	idx = strchr(type, '.');
	if (idx) *idx = 0;

	n = sizeof(type_list) / sizeof(struct con_arg);
	for (i=0, p = type_list; i<n; i++, p++) {
		if (strcmp(type, p->name) == 0) return i;
	}

	return -1;
}

int parse_crop_arg
(const char *str, uint32_t *x, uint32_t *y,
 uint32_t *cols, uint32_t *rows, uint32_t *cl)
{
	int n;
	char type[128];
	char *ptr, *idx;

	strncpy(type, str, 128);

	ptr = strchr(type, '.');
	if (!ptr) return -1;
	n = strtol(ptr+1, &idx, 10);
	if (n < 0 || idx == NULL || *idx != '.') return -1;
	*x = n;
	ptr = idx + 1;

	n = strtol(ptr, &idx, 10);
	if (n < 0 || idx == NULL || *idx != '.') return -1;
	*y = n;
	ptr = idx + 1;

	n = strtol(ptr, &idx, 10);
	if (n < 0 || idx == NULL || *idx != '.') return -1;
	*cols = n;
	ptr = idx + 1;

	n = strtol(ptr, &idx, 10);
	if (n < 0 || idx == NULL) return -1;
	*rows = n;

	if (*idx == '.') {
		ptr = idx + 1;
		n = atoi(ptr);
		if (n < 0) return -1;
		*cl = n;
	}

	return 0;
}

int check_work_arg(void *arg)
{
	int code;
	const char *rtype;
	struct evhttp_request *req = arg;

	rtype = get_req_header(req, "resize-type");
	if (rtype == NULL) return -1;

	code = get_scale_code(rtype);
	if (code == -1) return -1;

	if (type_list[code].type == CT_CROP) {
		int ret;
		uint32_t x,y,cols,rows,cl;
		ret = parse_crop_arg(rtype, &x, &y, &cols, &rows, &cl);
		return ret;
	}

	return 0;
}

int set_work_arg(tb_t *tb, void *arg)
{
	int ret;
	const char *rtype;
	struct evhttp_request *req = arg;
	struct scale_arg *sarg;

	sarg = (struct scale_arg *)tb->data;

	rtype = get_req_header(req, "resize-type");
	if (rtype == NULL) return -1;

	ret = get_scale_code(rtype);
	if (ret == -1) return -1;
	sarg->type = ret;

	if (type_list[ret].type == CT_CROP) {
		ret = parse_crop_arg(rtype, &sarg->x, &sarg->y,
				&sarg->cols, &sarg->rows, &sarg->cl);
		return ret;
	}

	return 0;
}

#define MAX_SCALE_DATA_SIZE (TASK_DATA_SIZE - sizeof(struct scale_arg))

uint8_t * set_work_data(tb_t *tb, void * data, size_t size)
{
	struct scale_arg *sarg;

	sarg = (struct scale_arg *)tb->data;

	if (size > MAX_SCALE_DATA_SIZE) return NULL;

	if (data != NULL) {
		memcpy(sarg->data, data, size);
	}
	sarg->size = size;
	tb->size = size + sizeof(struct scale_arg);

	return sarg->data;
}

uint8_t * get_work_data(tb_t *tb, size_t *size)
{
	struct scale_arg *sarg;

	sarg = (struct scale_arg *)tb->data;
	*size = sarg->size;
	return sarg->data;
}

struct worker_module scale_module = {
	NULL,
	check_work_arg,
	set_work_arg,
	set_work_data,
	get_work_data,
	convert,
	NULL,
};

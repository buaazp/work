#ifndef		__H_WORKER_H__
#define		__H_WORKER_H__
#include "task.h"

#define CMD_STOP_WORKER			1
#define CMD_REOPEN_LOG			2

typedef struct worker_module {
	int							(*mod_init)();
	int							(*check_work_arg)(void *);
	int							(*set_work_arg)(tb_t *, void *);
	uint8_t *					(*set_work_data)(tb_t *, void *, size_t);
	uint8_t *					(*get_work_data)(tb_t *, size_t *);
	int							(*mod_handle)(tb_t *);
	int							(*mod_exit)();
} wm_t;

typedef struct worker_info {
	pid_t						pid;
	int							pipe[2];
	tb_t						*task;
} wi_t;

int admin_worker(wi_t *info, int cmd);

#endif
